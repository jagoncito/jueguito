from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import webbrowser

web_dir = Path(__file__).resolve().parent / "web"
server = ThreadingHTTPServer(("127.0.0.1", 0), partial(SimpleHTTPRequestHandler, directory=str(web_dir)))
url = f"http://127.0.0.1:{server.server_port}/index.html"
print("Bītu está abierto en tu navegador. Cierra esta ventana o pulsa Ctrl+C para terminar.")
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
